package beans;
import java.util.ArrayList;
import java.util.List;
import beans.Movie;
import javax.faces.bean.ManagedBean;
//import javax.faces.view.ViewScoped;
import javax.faces.event.ActionEvent;
//Annotations
@ManagedBean
//@ViewScoped
public class Movies {
	//New Lists of type Movie.
	public List <Movie> movies = new ArrayList<Movie>(); 
	public List <Movie> purchasedTickets = new ArrayList<Movie>(); 
	// This default constructor has a predetermined set of data that
	// fills the properties from the Movie class.
	public Movies()	{
		movies.add(new Movie(0, "Avengers", 15.00, 1));
		movies.add(new Movie(1, "Captain America", 13.25, 1));
		movies.add(new Movie(2, "Joker", 11.50, 1));
		movies.add(new Movie(3, "Tenet", 14.50, 1));
		movies.add(new Movie(4, "Transformers", 12.00, 1));
		movies.add(new Movie(5, "Fast and the Furious", 14.75, 1));
		movies.add(new Movie(6, "Avatar", 15.25, 1));
		movies.add(new Movie(7, "Halloween", 11.25, 1));
		movies.add(new Movie(8, "Child's Play", 13.50, 1));
		movies.add(new Movie(9, "Toy Story", 11.75, 1));
		movies.add(new Movie(10, "Inside Out", 10.00, 1));
		movies.add(new Movie(11, "Twilight", 0.99, 1));
		movies.add(new Movie(12, "Harry Potter", 9.50, 1));
		movies.add(new Movie(13, "Star Wars", 15.00, 1));
	}	
	// These methods are used for individual buttons that add a specific movie to the purchasedTickets arraylist.
	public String onBuy1() {purchasedTickets.add(new Movie(1, "Avengers", 15.00, 1));return "ProductPage.xhtml";}
	public String onBuy2() {purchasedTickets.add(new Movie(2, "Captain America", 13.25, 1));return "ProductPage.xhtml";}
	public String onBuy3() {purchasedTickets.add(new Movie(3, "Joker", 11.50, 1));return "ProductPage.xhtml";}
	public String onBuy4() {purchasedTickets.add(new Movie(4, "Tenet", 14.50, 1));return "ProductPage.xhtml";}
	public String onBuy5() {purchasedTickets.add(new Movie(5, "Transformers", 12.00, 1));return "ProductPage.xhtml";}
	public String onBuy6() {purchasedTickets.add(new Movie(6, "Fast and the Furious", 14.75, 1));return "ProductPage.xhtml";}
	public String onBuy7() {purchasedTickets.add(new Movie(7, "Avatar", 15.25, 1));return "ProductPage.xhtml";}
	public String onBuy8() {purchasedTickets.add(new Movie(8, "Halloween", 11.25, 1));return "ProductPage.xhtml";}
	public String onBuy9() {purchasedTickets.add(new Movie(9, "Child's Play", 13.50, 1));return "ProductPage.xhtml";}
	public String onBuy10() {purchasedTickets.add(new Movie(10, "Toy Story", 11.75, 1));return "ProductPage.xhtml";}
	public String onBuy11() {purchasedTickets.add(new Movie(11, "Inside Out", 10.00, 1));return "ProductPage.xhtml";}
	public String onBuy12() {purchasedTickets.add(new Movie(12, "Twilight", 0.99, 1));return "ProductPage.xhtml";}
	public String onBuy13() {purchasedTickets.add(new Movie(13, "Harry Potter", 9.50, 1));return "ProductPage.xhtml";}
	public String onBuy14() {purchasedTickets.add(new Movie(14, "Star Wars", 15.00, 1));return "ProductPage.xhtml";}
	/*public boolean checkClicked(ActionEvent ev){
	    String buttonClickedID = ev.getComponent().getClientId();
	    // If the Buy button is clicked, add the movie to the list.
	    if (buttonClickedID.equals("myFormID:myButtonID")){
	        //Movie.isBought = true;
	        movies.add(new Movie(int orderNumber, String title, double price, int ticketNumber, boolean isBought));
	    }
	    return Movie();
	}*/
	// Getters and Setters
	public List<Movie> getMovies() {
		return movies;	}
	public void setMovies(List<Movie> movies) {
		this.movies = movies;	}
	public List<Movie> getPurchasedTickets() {
		return purchasedTickets;
	}
	public void setPurchasedTickets(List<Movie> purchasedTickets) {
		this.purchasedTickets = purchasedTickets;
	}		
}
