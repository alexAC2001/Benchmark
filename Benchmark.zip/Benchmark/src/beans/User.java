package beans;

import java.security.Principal;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.bean.ReferencedBean;

@ManagedBean
@ViewScoped
//@NotNull()
//@Size(min=5, max=15)
public class User {
	
	// New variables
	public static String username;
	public static String password;
	
	public static String firstName;
	public static String lastName;
	public static String emailAddress;
	public static int PhoneNumber;
	
	 /* public static void main(String[] args) {
		    productForm.search();     
		    productForm.ticketNumber();      
		    productForm.showtime();  
		//   buttons
		    productForm.search();  
		    productForm.save();        
		  }
	*/	
	// This is a default constructor that sets the username and password.
	public User() {
		username="user2000";
		password="123";
	}
	// Getters and setters for username and password.
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(int PhoneNumber) {
		this.PhoneNumber = PhoneNumber;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}	
	////////////
	@PostConstruct
	public void init() {
		// Get the logged in Principle
		Principal principle= FacesContext.getCurrentInstance().getExternalContext().getUserPrincipal();
			if(principle == null)
			{
				setFirstName("Unknown");
				setLastName("");
			}
			else
			{
				setFirstName(principle.getName());
				setLastName("");
			}

	}
	
}
